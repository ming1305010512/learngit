package org.lm.StringMethodTest;

/**
 * Created by 龙鸣 on 2017/8/5.
 */
public class StringMethodLearn {

    public static void main(String[] args) {
        String content="my name is longming";
        System.out.println(content.valueOf('i'));//返回'i'字符的字符串"i"
    }

}
